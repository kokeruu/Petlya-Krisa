using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemObject : MonoBehaviour
{
    public InventoryItemData referenceItem;

    private void OnMouseDown()
    {
        PickupItem();
    }

    public void PickupItem()
    {
        // Проверяем, есть ли инвентарь в сцене
        if (InventorySystem.current != null)
        {
            InventorySystem.current.Add(referenceItem);
            Destroy(gameObject);  
            Debug.Log("добавила!");
        }
        else
        {
            Debug.LogError("InventorySystem not found in scene!");
        }
    }
}