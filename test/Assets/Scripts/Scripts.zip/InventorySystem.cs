using System;
using System.Collections.Generic;
using UnityEngine;

public class InventorySystem : MonoBehaviour
{
    public static InventorySystem current { get; private set; }  

    private Dictionary<InventoryItemData, InventoryItem> itemDictionary;
    public List<InventoryItem> inventory { get; private set; }
    public event Action OnInventoryChanged;
    private void Awake()
{
    Debug.Log($"InventorySystem Awake on GameObject: {gameObject.name}");
    current = this;  
    inventory = new List<InventoryItem>();
    itemDictionary = new Dictionary<InventoryItemData, InventoryItem>();
}

    public void Add(InventoryItemData referenceData)
    {
        if (itemDictionary.TryGetValue(referenceData, out InventoryItem value))
        {
            value.AddToStack();
        }
        else
        {
            InventoryItem newItem = new InventoryItem(referenceData);
            inventory.Add(newItem);
            itemDictionary.Add(referenceData, newItem);
        }
        OnInventoryChanged?.Invoke();
        LogInventory($"Added item: {referenceData.displayName}");
    }

    public void Remove(InventoryItemData referenceData)
    {
        if (itemDictionary.TryGetValue(referenceData, out InventoryItem value))
        {
            value.RemoveFromStack();
            if (value.stackSize == 0)
            {
                inventory.Remove(value);
                itemDictionary.Remove(referenceData);
            }
             OnInventoryChanged?.Invoke();
            LogInventory($"Removed item: {referenceData.displayName}");
        }
    }

    public InventoryItem Get(InventoryItemData referenceData)
    {
        itemDictionary.TryGetValue(referenceData, out InventoryItem value);
        return value;
    }

    // Метод для логирования содержимого инвентаря
    private void LogInventory(string action)
    {
        Debug.Log($"{action} - Current inventory:");
        
        if (inventory.Count == 0)
        {
            Debug.Log("Inventory is empty");
            return;
        }
        
        foreach (var item in inventory)
        {
            Debug.Log($"- {item.data.displayName}: {item.stackSize}");
        }
    }
    
    // Можно добавить метод для ручной проверки инвентаря
    public void LogCurrentInventory()
    {
        LogInventory("Current inventory state:");
    }
}

[Serializable]
public class InventoryItem
{
    public InventoryItemData data { get; private set; }
    public int stackSize { get; private set; }

    public InventoryItem(InventoryItemData source)
    {
        data = source;
        AddToStack();
    }

    public void AddToStack()
    {
        stackSize++;
    }

    public void RemoveFromStack()
    {
        stackSize--;
    }
}