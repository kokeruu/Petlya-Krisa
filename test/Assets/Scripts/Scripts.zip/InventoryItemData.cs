using UnityEngine;

[CreateAssetMenu(menuName = "Inventory Item Data")]
public class InventoryItemData : ScriptableObject
{
    [Header("Basic Info")]
    public string id;
    public string displayName;
    public Sprite icon;
    public GameObject prefab;
    
    [Header("Item Actions")]
    [Tooltip("Можно ли использовать этот предмет")]
    public bool canBeUsed = false;
    
    [Tooltip("Можно ли комбинировать этот предмет с другими")]
    public bool canBeCombined = false;
    
    [Tooltip("Можно ли осматривать этот предмет")]
    public bool canBeExamined = true;
    
    [Header("Usage Settings")]
    [Tooltip("Эффект при использовании")]
    public float useEffectValue;
    
    [TextArea(3, 10)]
    [Tooltip("Описание при изучении предмета")]
    public string examineDescription;
    
    [Header("Combine Settings")]
    [Tooltip("ID предметов, с которыми можно комбинировать")]
    public string[] combinableWith;
    
    [Tooltip("Результирующий предмет после комбинации")]
    public InventoryItemData combinationResult;
    
    [Header("UI Settings")]
    [Tooltip("Цвет фона для слота с этим предметом")]
    public Color slotBackgroundColor = Color.white;
    
    [Tooltip("Дополнительный звук при взаимодействии")]
    public AudioClip interactionSound;
}